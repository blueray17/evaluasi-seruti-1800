from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import toml
import os
import httpx

app = FastAPI()
BASE_DIR = os.path.dirname(__file__)
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

class QueryParams(BaseModel):
    kd_prov: str
    kd_kab: str
    tw: str
    raw: str
    limit: str

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    query_list = toml.load(os.path.join(BASE_DIR, "queries", "query_list.toml"))["query"]
    return templates.TemplateResponse("index.html", {"request": request, "query_list": query_list})

@app.get("/get-query/{query_id}")
async def get_query(query_id: str):
    queries = toml.load(os.path.join(BASE_DIR, "queries", "query_list.toml"))["query"]
    for q in queries:
        if q["id"] == query_id:
            return q
    return JSONResponse({"error": "Query not found"}, status_code=404)

@app.post("/proxy-seruti")
async def proxy(params: QueryParams):
    body = {
        "kd_prov": params.kd_prov,
        "kd_kab": params.kd_kab,
        "tw": params.tw,
        "raw": params.raw,
        "limit": params.limit
    }
    headers = {
        "Content-Type": "application/json",
        "x-requested-with": "XMLHttpRequest"
    }
    async with httpx.AsyncClient() as client:
        response = await client.post("https://webapps.bps.go.id/olah/seruti/resource/query/executeRaw",
                                     headers=headers, json=body, cookies={})
    return response.json()