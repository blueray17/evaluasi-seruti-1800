let chartInstance = null;

async function runQuery(queryId) {
  const res1 = await fetch(`/get-query/${queryId}`);
  const query = await res1.json();

  const res2 = await fetch("/proxy-seruti", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      kd_prov: query.kd_prov,
      kd_kab: query.kd_kab,
      tw: query.tw,
      raw: query.raw,
      limit: query.limit
    })
  });

  const data = await res2.json();

  document.getElementById("hasil").innerHTML = "";
  document.getElementById("chart").style.display = "none";

  if (query.tipe === "tabel") {
    const hasilDiv = document.getElementById("hasil");
    hasilDiv.innerHTML = renderTable(data);
  } else if (query.tipe === "grafik") {
    document.getElementById("chart").style.display = "block";
    renderChart(data);
  }
}

function renderTable(data) {
  if (!data.data || !data.data.length) return "Tidak ada data.";
  const keys = Object.keys(data.data[0]);
  let html = "<table><thead><tr>";
  for (const key of keys) html += `<th>${key}</th>`;
  html += "</tr></thead><tbody>";
  for (const row of data.data) {
    html += "<tr>";
    for (const key of keys) html += `<td>${row[key]}</td>`;
    html += "</tr>";
  }
  html += "</tbody></table>";
  return html;
}

function renderChart(data) {
  if (!data.data || !data.data.length) return;
  const keys = Object.keys(data.data[0]);
  const labelKey = keys[0];
  const valueKey = keys[1];

  const labels = data.data.map(item => item[labelKey]);
  const values = data.data.map(item => Number(item[valueKey]));
  const ctx = document.getElementById("chart").getContext("2d");

  if (chartInstance) chartInstance.destroy();
  chartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: valueKey,
        data: values,
        backgroundColor: "#4e79a7"
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        title: { display: true, text: "Grafik Hasil Query" }
      },
      scales: {
        x: { ticks: { autoSkip: false } },
        y: { beginAtZero: true }
      }
    }
  });
}